<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>about</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="main">
  <div class="header">
    <div class="block_header">
      <div class="logo"><a href="index.blade.php"><img src="/images/logo.gif" width="508" height="142" border="0" alt="logo" /></a></div>
      <div style="float:right;">
        <div class="clr"></div>
        <div class="menu">
          <ul>
            <li><a href="<?php echo e(url('index')); ?>"><span>Home</span></a></li>
            <li><a href="index.blade.php"><span>Blog</span></a></li>
            <li><a href="portfolio.blade.php"><span>Portfolio</span></a></li>
            <li><a href="about.blade.php" class="active"><span>About us</span></a></li>
            <li><a href="contact.blade.php"><span>Contact</span></a></li>
          </ul>
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="slider2">
    <div class="slider2_resize">
      <h2>About us</h2>
      <p>Many desktop publishing packages and web page editors<br />
        now use Lorem Ipsum as their default model text, and a search for lorem ipsum.</p>
    </div>
  </div>
  <div class="bg_for_search">
    <div class="bg_for_search_resize">
      <div class="search">
        <form id="form2" name="form2" method="post" action="">
          <b>Search:</b>
          <input type="text" name="textfield" id="textfield" class="text" />
          <input type="image" name="imageField" id="imageField" src="/images/search.gif" class="button_search" />
        </form>
      </div>
    </div>
  </div>
  <div class="body">
    <div class="body_resize">
      <div class="Welcome">
        <h2> Lorem ipsum simply</h2>
        <div class="bg"></div>
        <p>Lorem Ipsum is simply dummy text of the printing andtypesetting industry. </p>
        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. <br />
          It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. </p>
        <p>It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<br />
          Why do we use it?</p>
        <p>It is a long established fact that a reader will be distracted by the readable content of a page.</p>
        <p><a href="#">Learn More</a></p>
        <h2>Our Team</h2>
        <div class="bg"></div>
        <p>Lorem Ipsum is simply dummy text of the printing andtypesetting industry. </p>
        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. <br />
          It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. </p>
        <ul>
          <li><a href="#">Been the industry's standard dummy.</a></li>
          <li><a href="#">Simply dummy text orem.</a></li>
          <li><a href="#">Undustry's standard dummy text.</a></li>
          <li><a href="#">Been the industry's stan.</a></li>
        </ul>
        <p><a href="#">Learn More</a></p>
        <h2>Business Solutions</h2>
        <div class="bg"></div>
        <p>Lorem Ipsum is simply dummy text of the printing andtypesetting industry. </p>
        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. <br />
          It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. </p>
        <p>It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<br />
          Why do we use it?</p>
        <p>It is a long established fact that a reader will be distracted by the readable content of a page.</p>
        <p><a href="#">Learn More</a></p>
      </div>
      <div class="Latest">
        <h2>News company</h2>
        <div class="bg"></div>
        <div class="data">12. 01. 09</div>
        <p>&nbsp;</p>
        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer <a href="#">[...]</a></p>
        <div class="bg"></div>
        <div class="data">12. 01. 09</div>
        <p>&nbsp;</p>
        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer <a href="#">[...]</a></p>
        <div class="bg"></div>
        <p><a href="#" class="news">Archive News</a></p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <h2>Client Says</h2>
        <div class="bg2"></div>
        <p> <em>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco. </em></p>
        <p> -<em> <a href="#">John Doe</a>, Position Company Name</em></p>
      </div>
      <div class="clr"></div>
    </div>
    <div class="clr"></div>
  </div>
  <div class="footer">
    <div class="resize">
      <div>© Copyright Sitename.com. <a href="http://dreamtemplate.com/">dreamtemplate.com</a>. All Rights Reserved<br />
        <a href="index.blade.php">Home</a> | <a href="contact.blade.php">Contact</a> | <a href="blog.html">RSS</a></div>
    </div>
    <p class="clr"></p>
  </div>
</div>
</body>
</html>