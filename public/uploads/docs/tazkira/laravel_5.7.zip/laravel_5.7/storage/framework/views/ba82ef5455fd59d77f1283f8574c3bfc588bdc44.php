<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Main Layout</title>
    <!-- For bootstrap-->
    <script src="<?php echo e(asset('js/jquery.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" type="text/javascript"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-theme.min.css')); ?>">

</head>
<body style="background-color: #e7e6cc">
    
    <?php echo $__env->yieldContent('for_index'); ?>
</body>
</html>