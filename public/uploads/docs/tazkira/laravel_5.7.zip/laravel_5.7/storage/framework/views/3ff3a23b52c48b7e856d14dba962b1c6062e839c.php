<style>
    div#my_list {
        padding: 30px;
    }
    span {
        margin-right: 10px;
    }
    span#copyright {
        color: white;
    }
</style>
<footer style="height: 80px;width: 1000px;background-color: #0f0f0f;margin: auto">
<div id="my_list">
<span><a href="#"> home </a></span>
<span><a href="#"> services </a></span>
<span><a href="#"> portfolio </a></span>
<span><a href="#"> about </a></span>
<span><a href="#"> contact </a></span>
<span><a href="#"> follow me </a></span>
<span id="copyright" style="float: right"> &copy;2018, All rights reserved. </span>
</div>
</footer>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>