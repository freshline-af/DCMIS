<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>home</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="<?php echo e(asset("css/style.css")); ?>" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo e(asset("js/jquery.js")); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset("js/easySlider1.5.js")); ?>"></script>
<script type="text/javascript" charset="utf-8">
// <![CDATA[
$(document).ready(function(){	
	$("#slider").easySlider({
		controlsBefore:	'<p id="controls">',
		controlsAfter:	'</p>',
		auto: true, 
		continuous: true
	});	
});
// ]]>
</script>
<style type="text/css">
body { background:#2b2b2b url(/images/bg_home.png) repeat-x; }
#slider { margin:0; padding:0; list-style:none; }
#slider ul,
#slider li { margin:0; padding:0; list-style:none; }
/* 
    define width and height of list item (slide)
    entire slider area will adjust according to the parameters provided here
*/
#slider li { width:978px; height:212px !important; height:206px; overflow:hidden; }
p#controls { margin:0; position:relative; }
#prevBtn,
#nextBtn { display:block; margin:0; overflow:hidden; width:69px; height:23px; position:absolute; left:0; top:-50px; }
#nextBtn { left:75px; }
#prevBtn a { display:block; width:69px; height:23px; background:url(images/next_topic.gif) no-repeat 0 0; }
#nextBtn a { display:block; width:69px; height:23px; background:url(images/Prev_topic.gif) no-repeat 0 0; }
</style>
</head>
<body>
<div class="main">
  <div class="header">
    <div class="block_header">
      <div class="logo"><a href="index.blade.php"><img src="images/logo.gif" width="508" height="142" border="0" alt="logo" /></a></div>
      <div style="float:right;">
        <div class="clr"></div>
        <div class="menu">
          <ul>
            <li><a href="<?php echo e(url('/index')); ?>" class="active"><span>Home</span></a></li>
            <li><a href="index.blade.php"><span>Blog</span></a></li>
            <li><a href="portfolio.blade.php"><span>Portfolio</span></a></li>
            <li><a href="<?php echo e(url('about')); ?>"><span>About us</span></a></li>
            <li><a href="contact.blade.php"><span>Contact</span></a></li>
          </ul>
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="slider">
    <div class="slider_resize">
      <div id="slider">
        <ul>
          <li>
            <div>
              <p class="img"><img src="images/simple_text_img_1.jpg" alt="screen 1" width="251" height="205" /></p>
              <h2>Many desktop publishing packages and web page editors now use Lorem Ipsum as their default. </h2>
              <p>Many desktop publishing packages and web page editors now<br />
                use Lorem Ipsum as their default model text, and a search for lorem ipsum.</p>
            </div>
          </li>
          <li>
            <div>
              <p class="img"><img src="images/simple_text_img_2.jpg" alt="screen 1" width="251" height="205" /></p>
              <h2>Many desktop publishing packages and web page editors now use Lorem Ipsum as their default. </h2>
              <p>Many desktop publishing packages and web page editors now<br />
                use Lorem Ipsum as their default model text, and a search for lorem ipsum.</p>
            </div>
          </li>
          <li>
            <div>
              <p class="img"><img src="images/simple_text_img_3.jpg" alt="screen 1" width="251" height="205" /></p>
              <h2>Many desktop publishing packages and web page editors now use Lorem Ipsum as their default. </h2>
              <p>Many desktop publishing packages and web page editors now<br />
                use Lorem Ipsum as their default model text, and a search for lorem ipsum.</p>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
  <div class="bg_for_search">
    <div class="bg_for_search_resize">
      <div class="search">
        <form id="form2" name="form2" method="post" action="">
          <b>Search:</b>
          <input type="text" name="textfield" id="textfield" class="text" />
          <input type="image" name="imageField" id="imageField" src="images/search.gif" class="button_search" />
        </form>
      </div>
    </div>
  </div>
  <div class="body">
    <div class="body_resize">
      <div class="Welcome">
        <h2> Welcome to our website</h2>
        <div class="bg"></div>
        <p>Lorem Ipsum is simply dummy text of the printing andtypesetting industry. </p>
        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. <br />
          It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. </p>
        <p>It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<br />
          Why do we use it?</p>
        <p>It is a long established fact that a reader will be distracted by the readable content of a page.</p>
        <p><a href="#">Learn More</a></p>
      </div>
      <div class="Latest">
        <h2>News company</h2>
        <div class="bg"></div>
        <div class="data">12. 01. 09</div>
        <p>&nbsp;</p>
        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer <a href="#">[...]</a></p>
        <div class="bg"></div>
        <div class="data">12. 01. 09</div>
        <p>&nbsp;</p>
        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer <a href="#">[...]</a></p>
        <div class="bg"></div>
        <p><a href="#" class="news">Archive News</a></p>
      </div>
      <div class="clr"></div>
      <div class="bg2"></div>
      <div class="Welcome">
        <h2>Our Services</h2>
        <div class="bg"></div>
        <p><span><a href="#">Lorem Ipsum has been the industry's</a> standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic.</span></p>
        <h3>Service 1</h3>
        <div class="bg"></div>
        <img src="images/Serv_1.gif" alt="picture" width="54" height="54" />
        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
        <div class="bg"></div>
        <h3>Service 2</h3>
        <div class="bg"></div>
        <img src="images/Serv_2.gif" alt="picture" width="53" height="62" />
        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
        <div class="bg"></div>
        <h3>Service 3</h3>
        <div class="bg"></div>
        <img src="images/Serv_3.gif" alt="picture" width="53" height="59" />
        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
        <div class="bg"></div>
      </div>
      <div class="Latest">
        <h2>Recent Blog Posts</h2>
        <div class="bg"></div>
        <img src="images/recent_img.gif" alt="picture" width="51" height="48" />
        <p>Lorem Ipsum is simply dummy text of the<br />
          April 26th, 2009</p>
        <div class="bg"></div>
        <img src="images/recent_img.gif" alt="picture" width="51" height="48" />
        <p>Lorem Ipsum is simply dummy text of the<br />
          April 26th, 2009</p>
        <div class="bg"></div>
        <img src="images/recent_img.gif" alt="picture" width="51" height="48" />
        <p>Lorem Ipsum is simply dummy text of the<br />
          April 26th, 2009</p>
        <div class="bg"></div>
        <img src="images/recent_img.gif" alt="picture" width="51" height="48" />
        <p>Lorem Ipsum is simply dummy text of the<br />
          April 26th, 2009</p>
        <div class="bg"></div>
        <p><a href="#">Read More</a></p>
        <h2>Search This Website</h2>
        <div class="bg"></div>
        <div class="search2">
          <form id="form3" name="form3" method="post" action="">
            <label>
              <input name="textfield2" type="text" class="text" id="textfield2" value="Search Site:" />
            </label>
            <label>
              <input type="image" name="imageField" id="imageField3" src="images/search2.gif" class="button_search" />
            </label>
          </form>
        </div>
      </div>
      <div class="clr"></div>
    </div>
    <div class="clr"></div>
  </div>
  <div class="footer">
    <div class="resize">
      <div>© Copyright Sitename.com. <a href="http://dreamtemplate.com/">dreamtemplate.com</a>. All Rights Reserved<br />
        <a href="index.blade.php">Home</a> | <a href="contact.blade.php">Contact</a> | <a href="blog.html">RSS</a></div>
    </div>
    <p class="clr"></p>
  </div>
</div>
</body>
</html>