<style>
    div#bottom {
        width: 1000px;
        height: 120px;
        background-color: #454126;
        margin: auto;
    }
</style>
<div id="bottom">
</div>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>