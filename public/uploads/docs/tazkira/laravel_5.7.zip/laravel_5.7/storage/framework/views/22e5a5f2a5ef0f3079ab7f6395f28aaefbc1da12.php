<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>contact</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo e(asset('js/jquery.js')); ?>"></script>
<script type="text/javascript">
// <![CDATA[
jQuery(document).ready(function(){
	$('#contactform').submit(function(){				  
		var action = $(this).attr('action');
		$.post(action, { 
			name: $('#name').val(),
			email: $('#email').val(),
			company: $('#company').val(),
			subject: $('#subject').val(),
			message: $('#message').val()
		},
			function(data){
				$('#contactform #submit').attr('disabled','');
				$('.response').remove();
				$('#contactform').before('<p class="response">'+data+'</p>');
				$('.response').slideDown();
				if(data=='Message sent!') $('#contactform').slideUp();
			}
		); 
		return false;
	});
});
// ]]>
</script>
</head>
<body>
<div class="main">
  <div class="header">
    <div class="block_header">
      <div class="logo"><a href="index.blade.php"><img src="images/logo.gif" width="508" height="142" border="0" alt="logo" /></a></div>
      <div style="float:right;">
        <div class="clr"></div>
        <div class="menu">
          <ul>
            <li><a href="index.blade.php"><span>Home</span></a></li>
            <li><a href="index.blade.php"><span>Blog</span></a></li>
            <li><a href="portfolio.blade.php"><span>Portfolio</span></a></li>
            <li><a href="about.blade.php"><span>About us</span></a></li>
            <li><a href="contact.blade.php" class="active"><span>Contact</span></a></li>
          </ul>
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="slider2">
    <div class="slider2_resize">
      <h2>Contact us</h2>
      <p>Many desktop publishing packages and web page editors<br />
        now use Lorem Ipsum as their default model text, and a search for lorem ipsum.</p>
    </div>
  </div>
  <div class="bg_for_search">
    <div class="bg_for_search_resize">
      <div class="search">
        <form id="form2" name="form2" method="post" action="">
          <b>Search:</b>
          <input type="text" name="textfield" id="textfield" class="text" />
          <input type="image" name="imageField" id="imageField" src="images/search.gif" class="button_search" />
        </form>
      </div>
    </div>
  </div>
  <div class="body">
    <div class="body_resize">
      <div class="Welcome2">
        <h2> Lorem ipsum simply</h2>
        <div class="bg"></div>
        <p><strong>Lorem Ipsum is simply dummy text of the printing andtypesetting industry. </strong></p>
        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. <br />
          It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. </p>
        <div class="bg"></div>
        <form action="contact.php" method="post" id="contactform">
          <ol>
            <li>
              <label for="name">your name </label>
              <input id="name" name="name" class="text" />
            </li>
            <li>
              <label for="email">Your email </label>
              <input id="email" name="email" class="text" />
            </li>
            <li>
              <label for="company">Company Name</label>
              <input id="company" name="company" class="text" />
            </li>
            <li>
              <label for="subject">Subject</label>
              <input id="subject" name="subject" class="text" />
            </li>
            <li>
              <label for="message">message </label>
              <textarea id="message" name="message" rows="6" cols="50"></textarea>
            </li>
            <li class="buttons">
              <input type="image" name="imageField" id="imageField2" src="images/send.gif" />
            </li>
          </ol>
        </form>
      </div>
      <div class="Latest2">
        <h2>Get in Touch</h2>
        <div class="bg"> </div>
        <p>Lorem Ipsum is simply dummy text of the printing and typesetting <a href="#">industry.</a></p>
        <p><img src="images/Twitter.jpg" alt="picture" width="181" height="78" /></p>
        <div class="clr"></div>
        <p class="gray">1234 Make Believe<br />
          New York, NY 50210</p>
        <p class="gray">+123456789<br />
          +123456789<br />
          <a href="#">company@domainname.com </a></p>
      </div>
    </div>
    <div class="clr"></div>
  </div>
  <div class="footer">
    <div class="resize">
      <div>© Copyright Sitename.com. <a href="http://dreamtemplate.com/">dreamtemplate.com</a>. All Rights Reserved<br />
        <a href="index.blade.php">Home</a> | <a href="contact.blade.php">Contact</a> | <a href="blog.html">RSS</a></div>
    </div>
    <p class="clr"></p>
  </div>
</div>
</body>
</html>