@extends('layout.app')
<style>
    div#content {
        height: 300px;
        width: 1000px;
        margin: auto;
        background-color: #f3edb5;
    }
    div#first, div#second, div#third {
        width: 25%;
        position: relative;
        display: inline-block;
    }
    #first {
        margin-left: 100px;
        margin-top: 30px;
    }
    h4 {
        padding: 10px;
        background-color: #FFFFFF;
        text-align: center;
    }

</style>
<div id="content">
    <div id="first">
        <h4><span class="glyphicon glyphicon-info-sign"></span> Welcome </h4>
        <p><span>
            first line... <br>
            second line... <br>
            third line... <br>
            fourth line... <br>
        </span></p>
    </div>
    <div id="second">
        <h4><span class="glyphicon glyphicon-question-sign"></span> What we do </h4>
        <p><span>
            first line... <br>
            second line... <br>
            third line... <br>
            fourth line... <br>
        </span></p>
    </div>
    <div id="third">
        <h4><span class="glyphicon glyphicon-comment"></span> Our Services </h4>
        <p><span>
            first line... <br>
            second line... <br>
            third line... <br>
            fourth line... <br>
        </span></p>
    </div>
</div>