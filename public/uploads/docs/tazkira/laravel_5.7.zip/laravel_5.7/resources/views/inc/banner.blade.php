@extends('layout.app')
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <style>
        body {
            margin: 0px;
        }
    </style>
</head>
<body>
<div id="banner" style="height: 100px;background-color: #e7e6b9;margin: 0px">
</div>
</body>
</html>