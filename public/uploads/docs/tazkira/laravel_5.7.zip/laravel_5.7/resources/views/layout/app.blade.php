<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Main Layout</title>
    <!-- For bootstrap-->
    <script src="{{ asset('js/jquery.js')}}" type="text/javascript"></script>
    <script src="{{ asset('js/bootstrap.min.js') }}" type="text/javascript"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/bootstrap-theme.min.css') }}">

</head>
<body style="background-color: #e7e6cc">
    {{-- Banner --}}
    @yield('for_index')
</body>
</html>